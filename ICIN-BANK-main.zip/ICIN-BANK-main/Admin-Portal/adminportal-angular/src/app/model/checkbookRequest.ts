export class CheckbookRequest{
    id:number;
    accType: string;
    username: string;
    account: number;
    date: string;
    no_of_pages: number;
}